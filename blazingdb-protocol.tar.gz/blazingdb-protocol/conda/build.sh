#!/bin/bash
conda/build.sh 
