# NOTE you need to have the blazingsql-build.properties file inside the workspace_dir
workspace_dir=$PWD/workspace/
mkdir workspace/

working_directory=$PWD
blazingsql_build_properties=blazingsql-build.properties

cd $workspace_dir

# Clean the FAILED file (in case exists)
rm -rf FAILED 

# Load the build properties file
source $blazingsql_build_properties

if [ -z "$branch" ]; then
    branch=develop
fi

if [ -z "$build_type" ]; then
    build_type=Release
fi

if [ -z "$tests" ]; then
    tests=false
fi

#BEGIN set default optional arguments for build options (precompiler definitions, etc.)
if [ -z "$definitions" ]; then
    definitions=""
fi

if [ -z "$clean_before_build" ]; then
    clean_before_build=false
fi



#BEGIN functions

#usage: replace_str "hi jack :)" "jack" "mike" ... result "hi mike :)" 
function replace_str() {
    input=$1
    replace=$2
    with=$3
    result=${input/${replace}/${with}}
    echo $result
}

# converts string feature/branchx to feature_branchx
function normalize_branch_name() {
    branch_name=$1
    result=$(replace_str $branch_name "/" "_")
    echo $result
}

#END functions

echo "### Protocol - start ###"
#BEGIN blazingdb-protocol

cd $workspace_dir

if [ ! -d blazingdb-protocol_project ]; then
mkdir blazingdb-protocol_project
fi

project_dir=$workspace_dir/blazingdb-protocol_project

cd $project_dir

if [ ! -d $branch_name ]; then
mkdir $branch_name
cd $branch_name
git clone git@github.com:BlazingDB/blazingdb-protocol.git
fi

current_dir=$project_dir/$branch_name/

cd $current_dir/blazingdb-protocol
git checkout $branch
git pull

cd cpp

install_dir=$current_dir/install

cpp_build_dir=$current_dir/blazingdb-protocol/cpp/build/

if [ $clean_before_build == true ]; then
rm -rf $cpp_build_dir
fi

mkdir -p $cpp_build_dir

cd $cpp_build_dir

artifact_name=libblazingdb-protocol.a
rm -rf lib/$artifact_name

echo "### Protocol - cmake ###"
cmake -DCMAKE_BUILD_TYPE=$build_type \
  -DCMAKE_INSTALL_PREFIX:PATH=$CONDA_PREFIX  \
  -DCXX_DEFINES=$definitions \
  ..
if [ $? != 0 ]; then
exit 1
fi

echo "### Protocol - make install ###"
make -j$parallel install
if [ $? != 0 ]; then
exit 1
fi

cd $current_dir/blazingdb-protocol/java
echo "### Protocol - mvn ###"
mvn clean install -Dmaven.test.skip=true
if [ $? != 0 ]; then
exit 1
fi

java_build_dir=$current_dir/blazingdb-protocol/java/target/

#END blazingdb-protocol

# Package blazingdb-protocol/python
cd $workspace_dir
mkdir -p $output/blazingdb-protocol/python/
cp -r $current_dir/blazingdb-protocol/python/* $output/blazingdb-protocol/python/

echo "### Protocol - end ###"
