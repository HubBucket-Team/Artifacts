#!/bin/sh
echo "run mock orchestrator service"
cd cpp/build/ 
./bin/blazingdb_orchestator_service