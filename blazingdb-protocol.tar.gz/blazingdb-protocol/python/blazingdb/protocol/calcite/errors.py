from blazingdb.protocol.errors import Error


class SyntaxError(Error):
  """"""
