from blazingdb.protocol.errors import Error


class IOError(Error):
  """"""

