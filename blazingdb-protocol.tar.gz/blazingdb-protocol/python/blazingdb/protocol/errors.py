class Error(Exception):
  """"""

class CommunicationError(Error):
  """"""

