#!/bin/sh
echo "run mock ral service"
cd cpp/build/ 
./bin/blazingdb_ral_service